<?php $__env->startSection('title', "Detalhes do post: {$post->title}"); ?>

<?php $__env->startSection('content'); ?>

<h1>Detalhes do post <b><?php echo e($post->title); ?></b></h1>

<?php
    $pathImage = url('imgs/posts/default.png');

    if ($post->image)
        $pathImage = url("storage/posts/{$post->image}");
?>
<img src="<?php echo e($pathImage); ?>" alt="<?php echo e($post->title); ?>" class="img-circle">

<p><?php echo e($post->body); ?></p>

<form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="DELETE">
    <button type="submit" class="btn btn-danger">Deletar o post: <?php echo e($post->title); ?></button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>