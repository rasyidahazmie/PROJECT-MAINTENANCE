<?php $__env->startSection('title', 'Cadastrar Novo Post'); ?>

<?php $__env->startSection('content'); ?>

<h1>Cadastrar Post</h1>

<form action="<?php echo e(route('posts.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo $__env->make('posts._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>