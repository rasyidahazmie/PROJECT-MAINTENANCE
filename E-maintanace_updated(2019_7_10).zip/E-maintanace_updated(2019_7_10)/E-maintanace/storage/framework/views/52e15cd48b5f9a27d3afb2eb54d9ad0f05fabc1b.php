
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

  <meta charset="utf-8">
  <title>Maintenace of the Computer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <!-- -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <script src="<?php echo e(asset('js/Chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Chart.js/samples/utils.js')); ?>"></script>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/sweetalert2.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-toastr/toastr.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-toastr/toastr-rtl.css')); ?>" />

    <script src="<?php echo e(asset('jquery/jquery-2.1.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('bootstrap-toastr/toastr.js')); ?>"></script>

</head>

<body>
  <div id="app">
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel navbar-dark" style="height: 70px; box-shadow: 5px 3px 10px #aaaaaa; background-color: #ffffff8f; position: fixed; width: 100%; z-index: 400;">
            <div class="container ">
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('themes/img/logo_1.png')); ?>" alt="" width="230px"  class="logo" /></a>

                <!-- <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a> -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button> 

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav " id="ul_formedit" style="display: none;">
                        <a class="nav-link" href="<?php echo e(url('/formedit')); ?>" style="color: #460f0f;"><b>Form Edit</b></a>   
                    </ul>
                    <ul class="navbar-nav " id="ul_pcview" style="display: none;">
                        <a class="nav-link" href="<?php echo e(url('/pcview')); ?>" style="color: #460f0f;"><b>PC View</b></a>   
                    </ul>
                    <ul class="navbar-nav " id="ul_users" style="display: none;">
                        <a class="nav-link" href="<?php echo e(url('/users')); ?>" style="color: #460f0f;"><b>Users</b></a>   
                    </ul> 

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>" style="color: #460f0f;"><b><?php echo e(__('Login')); ?></b></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>" style="color: #460f0f;"><b><?php echo e(__('Register')); ?></b></a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item ">
                                <a id="navbarDropdown" class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="color: #460f0f;"><b>
                                    <?php echo e(Auth::user()->name); ?> </b><span class="caret"></span>
                                </a>      </li>                         

                                <li class="nav-item ">
                                    <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" style="color: #460f0f;">
                                        <b><?php echo e(__('Logout')); ?></b>
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            
                        <?php endif; ?>
                    </ul>
                </div>
            </div> 
        </nav> 
    <!-- end header -->
    <section id="featured" style=" padding-top: 70px; z-index: 500;">
            <div class="container ">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
    </section>
  </div>
  <footer>
  <div id="sub-footer" style="background: #101010; padding: 100px 0 0 0; color: #bbb;">
      </div>
      <div id="sub-footer" style="background: #0a0a0a; padding: 50px 0 0 0; color: #bbb;">
      </div>
    </footer>
  <a href="#" class="scrollup"><i class="icon-chevron-up icon-square icon-32 active"></i></a>
  <!-- javascript
    ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->



  <!-- Template Custom JavaScript File -->
  <!-- <script src="<?php echo e(asset('themes/js/custom.js')); ?>"></script> -->

  <script src="<?php echo e(URL::to('/')); ?>/" defer></script>  
</body>
</html>
