<?php $__env->startSection('title', 'Listagem dos posts'); ?>

<?php $__env->startSection('content'); ?>

<h1>
    Posts
    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus-square"></i>
    </a>
</h1>

<?php echo $__env->make('includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<ul class="media-list">
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li class="media">
        <div class="pull-left">
            <?php
                $pathImage = url('imgs/posts/default.png');

                if ($post->image)
                    $pathImage = url("storage/posts/{$post->image}");
            ?>
            <img src="<?php echo e($pathImage); ?>" alt="<?php echo e($post->title); ?>" class="img-circle" style="max-width: 60px; margin: 10px;">
        </div>
        <div class="media-body">
            <span class="text-muted pull-right">
                <small class="text-muted"><?php echo e($post->created_at->format('d/m/Y')); ?></small>
            </span>
            <strong class="text-success"><?php echo e('@' . $post->user->name); ?></strong>
            <p>
                <?php echo e($post->title); ?>

                <br>
                <a href="<?php echo e(route('posts.show', $post->id)); ?>">Detalhes</a> |
                <a href="<?php echo e(route('posts.edit', $post->id)); ?>">Editar</a>
            </p>
        </div>
    </li>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li class="media">
        <p>Nenhum post cadastrado!</p>
    </li>
    <?php endif; ?>

    <?php echo $posts->links(); ?>

</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>